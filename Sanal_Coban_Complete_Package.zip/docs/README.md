# Sanal Çoban CubeSat
A global sheep tracking system using 3 CubeSats and LoRa uplink.